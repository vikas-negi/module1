package com.capgemini.tcc.dao;

import java.sql.*;

import org.apache.log4j.Logger;
import org.apache.log4j.PropertyConfigurator;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.util.DBUtil;




public class PatientDAO implements IPatientDAO {

	Logger daoLogger=null;
	Connection con=null;
	Statement st=null;
	PreparedStatement pst=null;
	ResultSet rs=null;
	
	public PatientDAO()
	{
		daoLogger=Logger.getLogger(PatientDAO.class);
		PropertyConfigurator.configure("resources/log4j.properties");
	}
	
	@Override
	public int addPatientDetails(PatientBean patient) throws PatientException {
		// TODO Auto-generated method stub
		Timestamp date=new Timestamp(new java.util.Date().getTime());
		int data;
		try
		{
			con=DBUtil.getConn();
			String insertQry="Insert into patient values (Patient_Id_Seq.NEXTVAL,?,?,?,?,?)";
			pst=con.prepareStatement(insertQry);
			pst.setString(1,patient.getPatient_name());
			pst.setInt(2,patient.getAge());
			pst.setString(3,patient.getPhone());
			pst.setString(4,patient.getDescription());
			pst.setTimestamp(5,patient.getConsultation_date());
			data=pst.executeUpdate();
		}
		catch(Exception e)
		{
			e.printStackTrace();
			throw new PatientException(e.getMessage());
		}
		daoLogger.info("All data retrieved  :" +data);
		return data;
	}

}
