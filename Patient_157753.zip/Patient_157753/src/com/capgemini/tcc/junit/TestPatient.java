package com.capgemini.tcc.junit;

import org.junit.Assert;
import org.junit.Test;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.PatientException;

public class TestPatient {

	PatientDAO p=new PatientDAO();
	
	@Test
	public void testInsert() throws PatientException
	{
		PatientBean p1=new PatientBean("Aman",45,"9456898326","NeckPain");
		Assert.assertEquals(1,p.addPatientDetails(p1));
	}
	
	@Test
	public void test1() throws PatientException
	{
		Assert.assertNotNull(p);
	}
	
}
