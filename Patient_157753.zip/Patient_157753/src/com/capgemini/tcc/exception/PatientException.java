package com.capgemini.tcc.exception;

public class PatientException extends Exception{

	String msg;
	//static Error code;
public PatientException(String msg)
{
	super(msg);
}

public PatientException(String msg,Throwable cause,Error code)
{
	super(msg,cause);
	//this.code=code;
}
}

