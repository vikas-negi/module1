package com.capgemini.tcc.service;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;


public interface IPatientService {

	int addPatientDetails(PatientBean patient) throws PatientException ;
	public boolean validatePatientName(String pName) throws PatientException;
	public boolean validatePatientPhone(String phone) throws PatientException;
	public boolean validatePatientAge(int age) throws PatientException;
}
