package com.capgemini.tcc.service;

import java.util.regex.Pattern;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.PatientDAO;
import com.capgemini.tcc.exception.PatientException;



public class PatientService implements IPatientService {

	PatientDAO empDao=null;
	public PatientService()
	{
		empDao=new PatientDAO();
	}
	
	@Override
	public int addPatientDetails(PatientBean patient) throws PatientException {
		// TODO Auto-generated method stub
		return empDao.addPatientDetails(patient);
	}

	@Override
	public boolean validatePatientName(String pName) throws PatientException {
		// TODO Auto-generated method stub
		
			String namePattern="[A-Z][a-z]+";
			if(Pattern.matches(namePattern,pName))
			{
				return true;
			}
			else
			{
				throw new PatientException("Invalid Patient Name");
			}
	}

	@Override
	public boolean validatePatientPhone(String phone) throws PatientException {
		// TODO Auto-generated method stub
	
			
			if(phone.length()==10)
			{
				return true;
			}
			else
			{
				throw new PatientException("Invalid Phone Number");
			}

	}

	@Override
	public boolean validatePatientAge(int age) throws PatientException {
		// TODO Auto-generated method stub
		if(age>=0 && age<=100)
		{
			return true;
		}
		else
		{
			throw new PatientException("Invalid Age");
		}
	}

}
