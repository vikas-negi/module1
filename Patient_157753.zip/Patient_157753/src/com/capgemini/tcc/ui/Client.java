package com.capgemini.tcc.ui;

import java.util.Scanner;

import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.exception.PatientException;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;





public class Client {
	static IPatientService patientService=null;
	static Scanner sc;

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		sc=new Scanner(System.in);
		System.out.println("*********** Welcome to TakeCare Clinic***********");
		int choice=0;		
		patientService=new PatientService();
		while(true)
		{
			System.out.println("What do u want to do ?");
			System.out.println("\t 1 : Add Patient \t 2 :  Exit ");
			System.out.println("Enter UR Choice : ");
			choice=sc.nextInt();
			switch(choice)
			{
			case 1: insertEmp(); break;
			case 2: System.exit(0);
			default:System.out.println("Invalid Choice");
			}
		}
	}

	private static void insertEmp() {
		// TODO Auto-generated method stub
		try {
			System.out.println("Enter Patient Name : ");
			String patientName=sc.next();
			if(patientService.validatePatientName(patientName))
			{

				System.out.println("Enter Age : ");
				int age=sc.nextInt();
				if(patientService.validatePatientAge(age))
				{
					System.out.println("Enter Phone No. : ");
					String phone=sc.next();
					if(patientService.validatePatientPhone(phone))
					{
						System.out.println("Enter Description : ");
						String description=sc.next();

						PatientBean patient=new PatientBean(patientName,age,phone,description);
						int dataInserted=patientService.addPatientDetails(patient);
						if(dataInserted==1)
						{
							System.out.println("Patient Information stored successfully for patient ");

							//dispAllPatient();
						}
						else
						{
							System.out.println("Sorry Patient Details not added");
						}
					}
				}
			}
		}
		
				catch (PatientException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}


			}
}
